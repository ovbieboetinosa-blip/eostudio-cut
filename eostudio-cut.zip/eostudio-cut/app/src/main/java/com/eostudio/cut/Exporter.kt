@file:OptIn(UnstableApi::class)

package com.eostudio.cut

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import androidx.media3.common.Effect
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File

object Exporter {
    /** Must be called on the main thread. Uses the phone's hardware H.264 encoder. */
    fun export(
        context: Context, clips: List<Clip>, height: Int,
        onDone: (String) -> Unit, onError: (String) -> Unit
    ) {
        val items = clips.map { c ->
            val video = mutableListOf<Effect>()
            val audio = mutableListOf<AudioProcessor>()
            if (c.speed != 1f) {
                video += SpeedChangeEffect(c.speed)
                audio += SonicAudioProcessor().apply { setSpeed(c.speed) }
            }
            video += Presentation.createForHeight(height)
            if (c.text.isNotBlank()) {
                val s = SpannableString(c.text).apply {
                    setSpan(ForegroundColorSpan(Color.WHITE), 0, length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                    setSpan(RelativeSizeSpan(1.2f), 0, length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                video += OverlayEffect(ImmutableList.of<TextureOverlay>(TextOverlay.createStaticTextOverlay(s)))
            }
            EditedMediaItem.Builder(c.toMediaItem())
                .setRemoveAudio(c.muted)
                .setEffects(Effects(audio, video))
                .build()
        }
        val composition = Composition.Builder(listOf(EditedMediaItemSequence(items))).build()
        val out = File(context.cacheDir, "eos_export.mp4").also { if (it.exists()) it.delete() }

        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    onDone(saveToGallery(context, out))
                }
                override fun onError(
                    composition: Composition, exportResult: ExportResult, exportException: ExportException
                ) { onError(exportException.message ?: "Export failed") }
            }).build()
        transformer.start(composition, out.absolutePath)
    }

    private fun saveToGallery(ctx: Context, f: File): String {
        val name = "EOStudioCut_${System.currentTimeMillis()}.mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/EOStudioCut")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
            if (uri != null) {
                ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                return "Saved to Movies/EOStudioCut"
            }
        }
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.filesDir
        val dest = File(dir, name)
        f.copyTo(dest, true)
        return "Saved: ${dest.path}"
    }
}
