package com.eostudio.cut

import android.app.Application
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Clip(
    val id: Long,
    val uri: Uri,
    val sourceMs: Long,
    val startMs: Long,
    val endMs: Long,
    val speed: Float = 1f,
    val muted: Boolean = false,
    val text: String = ""
) {
    val timelineMs: Long get() = ((endMs - startMs) / speed).toLong()

    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setUri(uri)
        .setClippingConfiguration(
            MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs).setEndPositionMs(endMs).build()
        ).build()
}

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    var clips by mutableStateOf(listOf<Clip>())
        private set
    var selectedId by mutableStateOf<Long?>(null)
        private set
    private var nextId = 1L

    val selected: Clip? get() = clips.firstOrNull { it.id == selectedId }

    private fun durationOf(uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(getApplication<Application>(), uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) { 0L } finally { r.release() }
    }

    fun importClips(uris: List<Uri>) {
        viewModelScope.launch {
            val added = withContext(Dispatchers.IO) {
                uris.mapNotNull { u -> durationOf(u).takeIf { it > 0 }?.let { Clip(nextId++, u, it, 0, it) } }
            }
            clips = clips + added
            if (selectedId == null) selectedId = added.firstOrNull()?.id
        }
    }

    fun select(id: Long) { selectedId = id }

    private fun update(id: Long, f: (Clip) -> Clip) { clips = clips.map { if (it.id == id) f(it) else it } }

    fun trim(id: Long, start: Long, end: Long) = update(id) {
        val s = start.coerceIn(0, it.sourceMs - 300)
        it.copy(startMs = s, endMs = end.coerceIn(s + 300, it.sourceMs))
    }
    fun setSpeed(id: Long, v: Float) = update(id) { it.copy(speed = v) }
    fun toggleMute(id: Long) = update(id) { it.copy(muted = !it.muted) }
    fun setText(id: Long, t: String) = update(id) { it.copy(text = t) }

    fun split(id: Long, atSourceMs: Long): Boolean {
        val i = clips.indexOfFirst { it.id == id }
        if (i < 0) return false
        val c = clips[i]
        if (atSourceMs <= c.startMs + 300 || atSourceMs >= c.endMs - 300) return false
        val b = c.copy(id = nextId++, startMs = atSourceMs, text = "")
        clips = clips.toMutableList().apply { set(i, c.copy(endMs = atSourceMs)); add(i + 1, b) }
        selectedId = b.id
        return true
    }

    fun deleteSelected() {
        val i = clips.indexOfFirst { it.id == selectedId }
        if (i < 0) return
        clips = clips.toMutableList().apply { removeAt(i) }
        selectedId = clips.getOrNull(i.coerceAtMost(clips.lastIndex))?.id
    }

    fun moveSelected(dir: Int) {
        val i = clips.indexOfFirst { it.id == selectedId }
        val j = i + dir
        if (i < 0 || j !in clips.indices) return
        clips = clips.toMutableList().apply { val t = this[i]; this[i] = this[j]; this[j] = t }
    }
}
