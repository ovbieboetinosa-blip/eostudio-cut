package com.eostudio.cut

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

val Bg = Color(0xFF161618)
val Panel = Color(0xFF222226)
val Panel2 = Color(0xFF2C2C31)
val Accent = Color(0xFFFF6A3D)
val Teal = Color(0xFF2F8F9D)
val TealDim = Color(0xFF225E68)
val Green = Color(0xFF3F9E5C)
val Dim = Color(0xFF9A9AA2)

const val DP_PER_SEC = 36f
const val PAD = 8f

enum class Tool { NONE, TRIM, SPEED, TEXT, AUDIO }

fun fmt(ms: Long): String {
    val t = ms.coerceAtLeast(0)
    return "%02d:%02d.%d".format(t / 60000, (t / 1000) % 60, (t % 1000) / 100)
}

@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    val clips = vm.clips
    val selected = vm.selected
    var playing by remember { mutableStateOf(false) }
    var playheadMs by remember { mutableLongStateOf(0L) }
    var tool by remember { mutableStateOf(Tool.NONE) }
    var exporting by remember { mutableStateOf(false) }
    var hd by remember { mutableStateOf(false) }
    val scroll = rememberScrollState()
    val density = LocalDensity.current.density
    val halfScreenDp = LocalConfiguration.current.screenWidthDp / 2f

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
        vm.importClips(it)
    }
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    // Rebuild preview playlist only when the cut points change (not speed/text/mute).
    val sig = clips.map { Triple(it.uri, it.startMs, it.endMs) }
    LaunchedEffect(sig) {
        if (clips.isEmpty()) { player.clearMediaItems(); playheadMs = 0 }
        else {
            val idx = player.currentMediaItemIndex.coerceIn(0, clips.lastIndex)
            player.setMediaItems(clips.map { it.toMediaItem() }, idx, player.currentPosition)
            player.prepare()
        }
    }

    // Playhead sync + per-clip preview speed/mute.
    LaunchedEffect(Unit) {
        while (true) {
            val list = vm.clips
            val i = player.currentMediaItemIndex
            if (i in list.indices && player.mediaItemCount == list.size) {
                val c = list[i]
                if (player.playbackParameters.speed != c.speed) player.setPlaybackSpeed(c.speed)
                player.volume = if (c.muted) 0f else 1f
                playheadMs = list.take(i).sumOf { it.timelineMs } + (player.currentPosition / c.speed).toLong()
            }
            delay(50)
        }
    }
    LaunchedEffect(playheadMs) {
        if (playing) scroll.scrollTo(((playheadMs / 1000f * DP_PER_SEC + PAD - halfScreenDp) * density).toInt().coerceAtLeast(0))
    }

    val totalMs = clips.sumOf { it.timelineMs }
    val seek: (Long) -> Unit = { ms ->
        var acc = 0L
        var done = false
        for ((i, c) in clips.withIndex()) {
            if (!done && (ms < acc + c.timelineMs || i == clips.lastIndex)) {
                player.seekTo(i, ((ms - acc).coerceAtLeast(0) * c.speed).toLong())
                vm.select(c.id); done = true
            }
            acc += c.timelineMs
        }
    }
    val current = run {
        var acc = 0L
        clips.firstOrNull { c -> (playheadMs < acc + c.timelineMs).also { if (!it) acc += c.timelineMs } }
    }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()) {
        // Top bar
        Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("EOSTUDIO CUT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 2.sp)
            Spacer(Modifier.weight(1f))
            Chip(if (hd) "1080p" else "720p", false) { hd = !hd }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.clip(RoundedCornerShape(6.dp)).background(if (exporting) Dim else Accent)
                .clickable(enabled = !exporting) {
                    if (clips.isEmpty()) { toast("Import a clip first"); return@clickable }
                    player.pause(); exporting = true; toast("Exporting…")
                    Exporter.export(ctx, clips, if (hd) 1080 else 720,
                        onDone = { exporting = false; toast(it) },
                        onError = { exporting = false; toast(it) })
                }.padding(horizontal = 14.dp, vertical = 7.dp)) {
                Text(if (exporting) "Exporting…" else "Export", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        // Preview
        Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black), contentAlignment = Alignment.Center) {
            AndroidView(factory = { PlayerView(it).apply { useController = false; this.player = player } },
                modifier = Modifier.fillMaxSize())
            if (clips.isEmpty()) Text("Tap + to import video", color = Dim, fontSize = 14.sp)
            current?.text?.takeIf { it.isNotBlank() }?.let {
                Text(it, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp))
            }
        }

        // Transport
        Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(fmt(playheadMs), color = Accent, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            ToolButton("⏮", "Start") { seek(0) }
            ToolButton(if (playing) "❚❚" else "▶", if (playing) "Pause" else "Play") {
                if (clips.isEmpty()) return@ToolButton
                if (playing) player.pause() else {
                    if (player.playbackState == Player.STATE_ENDED) seek(0)
                    player.play()
                }
            }
            ToolButton("⏭", "Next") { player.seekToNextMediaItem() }
            Spacer(Modifier.weight(1f))
            Text(fmt(totalMs), color = Dim, fontSize = 13.sp)
        }

        Timeline(clips, vm.selectedId, playheadMs, scroll, seek)

        Inspector(tool, selected, vm)

        // Tool dock
        Row(Modifier.fillMaxWidth().background(Panel).horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            ToolButton("+", "Import") { picker.launch(arrayOf("video/*")) }
            ToolButton("✂", "Split") {
                val c = current ?: return@ToolButton
                if (!vm.split(c.id, c.startMs + player.currentPosition)) toast("Put the playhead inside a clip")
            }
            ToolButton("✕", "Delete") { vm.deleteSelected() }
            ToolButton("◀", "Move") { vm.moveSelected(-1) }
            ToolButton("▶", "Move") { vm.moveSelected(1) }
            ToolButton("[ ]", "Trim", tool == Tool.TRIM) { tool = if (tool == Tool.TRIM) Tool.NONE else Tool.TRIM }
            ToolButton("»", "Speed", tool == Tool.SPEED) { tool = if (tool == Tool.SPEED) Tool.NONE else Tool.SPEED }
            ToolButton("T", "Text", tool == Tool.TEXT) { tool = if (tool == Tool.TEXT) Tool.NONE else Tool.TEXT }
            ToolButton("♪", "Audio", tool == Tool.AUDIO) { tool = if (tool == Tool.AUDIO) Tool.NONE else Tool.AUDIO }
        }
    }
}

@Composable
fun Timeline(clips: List<Clip>, selectedId: Long?, playheadMs: Long, scroll: ScrollState, onTap: (Long) -> Unit) {
    val density = LocalDensity.current.density
    val tap by rememberUpdatedState(onTap)
    val totalMs = clips.sumOf { it.timelineMs }
    val contentW = (totalMs / 1000f * DP_PER_SEC + 2 * PAD + 160).dp

    Box(Modifier.fillMaxWidth().height(150.dp).background(Bg).horizontalScroll(scroll)) {
        Box(Modifier.width(contentW).fillMaxHeight().pointerInput(clips) {
            detectTapGestures { o ->
                tap(((o.x / density - PAD) / DP_PER_SEC * 1000).toLong().coerceAtLeast(0))
            }
        }) {
            Canvas(Modifier.fillMaxWidth().height(24.dp)) {
                val secs = (totalMs / 1000).toInt() + 4
                for (s in 0..secs) {
                    val x = (PAD + s * DP_PER_SEC) * density
                    val h = if (s % 5 == 0) 14.dp.toPx() else 7.dp.toPx()
                    drawLine(Dim, Offset(x, size.height - h), Offset(x, size.height), 1.5f)
                }
            }
            Row(Modifier.padding(start = PAD.dp, top = 30.dp)) {
                clips.forEachIndexed { i, c ->
                    val sel = c.id == selectedId
                    Box(Modifier.width((c.timelineMs / 1000f * DP_PER_SEC).dp.coerceAtLeast(14.dp)).height(64.dp)
                        .padding(end = 2.dp).clip(RoundedCornerShape(4.dp))
                        .background(if (sel) Teal else TealDim)
                        .then(if (sel) Modifier.border(2.dp, Accent, RoundedCornerShape(4.dp)) else Modifier)
                        .padding(4.dp)) {
                        Text("V${i + 1}" + (if (c.speed != 1f) "  ${c.speed}x" else "") +
                            (if (c.text.isNotBlank()) "  T" else ""),
                            fontSize = 10.sp, color = Color.White, maxLines = 1)
                    }
                }
            }
            Row(Modifier.padding(start = PAD.dp, top = 100.dp)) {
                clips.forEachIndexed { i, c ->
                    Box(Modifier.width((c.timelineMs / 1000f * DP_PER_SEC).dp.coerceAtLeast(14.dp)).height(24.dp)
                        .padding(end = 2.dp).clip(RoundedCornerShape(4.dp))
                        .background(if (c.muted) Panel2 else Green).padding(horizontal = 4.dp)) {
                        Text(if (c.muted) "MUTED" else "A${i + 1}", fontSize = 9.sp, color = Color.White, maxLines = 1)
                    }
                }
            }
            Box(Modifier.offset(x = (PAD + playheadMs / 1000f * DP_PER_SEC).dp).width(2.dp).fillMaxHeight().background(Accent))
        }
    }
}

@Composable
fun Inspector(tool: Tool, c: Clip?, vm: EditorViewModel) {
    if (tool == Tool.NONE || c == null) return
    Column(Modifier.fillMaxWidth().background(Panel2).padding(12.dp)) {
        when (tool) {
            Tool.TRIM -> {
                var range by remember(c.id, c.startMs, c.endMs) { mutableStateOf(c.startMs.toFloat()..c.endMs.toFloat()) }
                Text("IN ${fmt(range.start.toLong())}   OUT ${fmt(range.endInclusive.toLong())}   DUR ${fmt((range.endInclusive - range.start).toLong())}",
                    color = Color.White, fontSize = 12.sp)
                @OptIn(ExperimentalMaterial3Api::class)
                RangeSlider(value = range, onValueChange = { range = it },
                    valueRange = 0f..c.sourceMs.toFloat(),
                    onValueChangeFinished = { vm.trim(c.id, range.start.toLong(), range.endInclusive.toLong()) })
            }
            Tool.SPEED -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f).forEach { s -> Chip("${s}x", c.speed == s) { vm.setSpeed(c.id, s) } }
            }
            Tool.TEXT -> OutlinedTextField(value = c.text, onValueChange = { vm.setText(c.id, it) },
                label = { Text("Text overlay") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Tool.AUDIO -> Chip(if (c.muted) "Unmute clip" else "Mute clip", c.muted) { vm.toggleMute(c.id) }
            else -> {}
        }
    }
}

@Composable
fun ToolButton(glyph: String, label: String, active: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.width(52.dp).clip(RoundedCornerShape(6.dp))
        .background(if (active) Panel2 else Color.Transparent).clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(glyph, color = if (active) Accent else Color.White, fontSize = 18.sp)
        Text(label, color = if (active) Accent else Dim, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
fun Chip(text: String, active: Boolean, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(16.dp)).background(if (active) Accent else Panel2)
        .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text(text, color = Color.White, fontSize = 12.sp)
    }
}
