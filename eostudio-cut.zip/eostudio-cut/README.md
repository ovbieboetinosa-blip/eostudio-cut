# EOStudio Cut
Offline video editor, built for the Oppo F11.

- `docs/`  Chrome web app (PWA). Host it with GitHub Pages, install it, use it offline.
- `app/`   Native Android app (Kotlin + Media3, hardware export). Built into an APK by GitHub Actions.

## Web app (use now)
Settings > Pages > Deploy from a branch > `main` / `/docs` > Save.
Open https://YOUR-USERNAME.github.io/REPO-NAME/ in Chrome once while online,
then Chrome menu > Install app. After that it works with no internet.
Web export records in real time and saves .mp4 (or .webm if Chrome lacks mp4 recording).

## APK
Actions tab > Build APK > Run workflow (it also runs on every push).
When it finishes, open the run and download the `EOStudioCut-apk` artifact (a zip containing the .apk).
Install it on the phone (allow unknown sources).
